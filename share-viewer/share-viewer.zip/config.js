window.SHARE_API_BASE = "https://competencypassport-api.azurewebsites.net";
